﻿namespace TeamProject1.Models
{
    public class Ingredient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Calories { get; set; }
    }
}
