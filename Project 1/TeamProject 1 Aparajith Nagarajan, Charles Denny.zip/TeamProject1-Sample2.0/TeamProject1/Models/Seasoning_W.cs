﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TeamProject1.Models
{
    public class Seasoning_W
    {
        public Seasoning Seasoning { get; set; }
        public decimal Weight { get; set; }
    }
}
